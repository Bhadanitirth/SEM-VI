import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Form from './component/Form';
import Display from './component/Display';

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Form />} />
                <Route path="/display" element={<Display />} />
            </Routes>
        </Router>
    );
}

export default App;
