import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Form() {
    const [data, setData] = useState({
        sem: '',
        sub: '',
        subTech: ''
    });

    const navigate = useNavigate();

    const handleChange = (e) => {
        setData({
            ...data,
            [e.target.name]: e.target.value
        });
    };

    const sub = (e) => {
        e.preventDefault();
        navigate('/display', { state: data }); // 🔁 pass data to display page
    };

    return (
        <div>
            <form onSubmit={sub}>
                no: <input type="number" onChange={handleChange} name="sem" /><br />
                sub: <input type="text" name="sub" onChange={handleChange} /><br />
                subTech: <input type="text" name="subTech" onChange={handleChange} /><br />
                <input type="submit" value="submit" />
            </form>
        </div>
    );
}

export default Form;
