import React from 'react';
import { useLocation,useNavigate } from 'react-router-dom';

function Display() {
    const location = useLocation();
    const data = location.state;

    const navigate=useNavigate();

    const back = ()=> {
        navigate('/');
    };

    return (
        <div>
            <h2>Submitted Data</h2>
            <p>Semester: {data.sem}</p>
            <p>Subject: {data.sub}</p>
            <p>Subject Teacher: {data.subTech}</p>
            <button onClick={back}>Back</button>
        </div>
    );
}

export default Display;
