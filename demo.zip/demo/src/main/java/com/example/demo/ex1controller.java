package com.example.demo;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/ex1")
public class ex1controller {

    public final Map<Long,Student> stuData = new HashMap<>();
    private Long id= Long.valueOf(1);

    @PostMapping
    public Student createStd(@RequestBody Student stu){
        stu.setSid(id++);
        stuData.put(stu.getSid(),stu);
        return stu;
    }

    @GetMapping
    public List<Student> getallStu(){
        return new ArrayList<>(stuData.values());
    }

    @GetMapping("/{id}")
    public Student getStubyId(@PathVariable Long id){
        return stuData.get(id);
    }

    @DeleteMapping("/{id}")
    public Long deleteStubyId(@PathVariable Long id){
        stuData.remove(id);
        return id;
    }

    @PostMapping("/{id}")
    public Student update(@RequestBody Student stu,@PathVariable Long id){
        Student s=stuData.get(id);
        s.setName(stu.getName());
        s.setAge(stu.getAge());
        return s;
    }

}
