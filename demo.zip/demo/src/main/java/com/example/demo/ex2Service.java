package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ex2Service {

//    private Map<Long,Student> stuSer = new HashMap<>();
//    private Long id = Long.valueOf(1);

    @Autowired
    private ex3Repository stuSer;

    public List<Student> getStudents() {
//        return new ArrayList<>(stuSer.values());
        return stuSer.findAll();
    }

    public Student getStudent(Long id) {
//        return stuSer.get(id);
        return stuSer.findById(id).get();
    }

    public Student createStu(Student stu) {
//        stu.setSid(id++);
//        stuSer.put(stu.getSid(),stu);
//        return stu;
        return stuSer.save(stu);
    }

    public Student updateStu(Student stu, Long id) {
//            Student s=stuSer.get(id);
//            s.setName(stu.getName());
//            s.setAge(stu.getAge());
//            return s;
        Student s = stuSer.findById(id).get();
        s.setName(stu.getName());
        s.setAge(stu.getAge());
        return stuSer.save(s);
    }

    public Long deleteStu(Long id) {
//            stuSer.remove(id);
//            return id;
        stuSer.deleteById(id);
        return id;
    }
}
