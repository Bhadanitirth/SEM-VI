package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ex2")
public class ex2Controller {

    @Autowired
    private ex2Service ex2Service;

    @GetMapping
    public List<Student> getStudents() {
        return ex2Service.getStudents();
    }

    @GetMapping("/{id}")
    public Student getStudent(@PathVariable Long id){
        return ex2Service.getStudent(id);
    }

    @PostMapping("/{id}")
    public Student updateStu(@PathVariable Long id,@RequestBody Student stu){
        return ex2Service.updateStu(stu,id);
    }

    @PostMapping
    public Student addStu(@RequestBody Student stu){
        return ex2Service.createStu(stu);
    }

    @DeleteMapping("/{id}")
    public Long deleteStu(@PathVariable Long id) {
        return ex2Service.deleteStu(id);
    }
}
